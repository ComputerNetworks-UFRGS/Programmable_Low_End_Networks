#!/usr/bin/env python3

import subprocess
import os
import re
import sys
from time import sleep, time
import matplotlib.pyplot as plt
import threading

def run_script(script_name, mode):
    subprocess.run(["python", script_name, "-m", mode])

def convert_size(size_str):
    """Convert size string (e.g., '10K', '100M') to bytes."""
    suffix = size_str[-1]
    number = size_str[:-1]
    numer = number.replace(',', '.')


    if suffix == 'K':
        return float(numer)
    elif suffix == 'M':
        return float(numer) * 10 ** 3
    elif suffix == 'G':
        return float(numer) * 10 ** 6
    return float(numer)

files = [
#    "143.54.48.186/downloads/A1M.txt",
#    "143.54.48.186/downloads/A10M.txt",
#    "143.54.48.186/downloads/AB1M.txt",
#    "143.54.48.186/downloads/AB10M.txt",
#    "143.54.48.186/downloads/ABC1M.txt",
#    "143.54.48.186/downloads/ABC10M.txt",
#    "143.54.48.186/downloads/example-fake-zip-file-1mb.zip"
    '143.54.50.1/downloads/blocks_1B',
    '143.54.50.1/downloads/blocks_2B',
    '143.54.50.1/downloads/blocks_4B',
    '143.54.50.1/downloads/blocks_8B',
    '143.54.50.1/downloads/blocks_16B',
    '143.54.50.1/downloads/blocks_32B',
    '143.54.50.1/downloads/blocks_64B',
    '143.54.50.1/downloads/blocks_128B',
    '143.54.50.1/downloads/example-fake-zip-file-1mb.zip'
]

p4 = [
#    "trim-and-compress"
    "simple-forward"
]

for program in p4:

#    os.system(f"echo {program} > ../t4p4s-switch")
#    os.system("systemctl restart bmv2.service")

#    sleep(1)

#    os.system("systemctl is-active bmv2.service")

    lora = threading.Thread(target=run_script, args=("transceiver2.py", program))
    lora.daemon = True
    lora.start()
    print("Running {}".format(program))

    for file in files:
        speeds = [0] * 10000
        max_time = 0
        for i in range(10):
            process = subprocess.Popen(['wget', file, '-P', 'TRASH/'], stderr=subprocess.PIPE)

            #speeds = []
            #timestamps = []

            current_second_speeds = []  # To collect speeds for averaging
            started = False
            #start_time = time()
            last_recorded_time = 0
            time = 0

            for line in process.stderr:
                line = line.decode("utf-8", "replace")

                if started:
                    elapsed_time = time() - start_time
                    splited = line.split()
                    if len(splited) == 9:
                        speed = splited[7]
                        print(splited[6])
                        current_speed = convert_size(speed)  # Convert to KB/s
                        current_second_speeds.append(current_speed)  # Collect speed for this second

                # Calculate average speed every second
                    if elapsed_time - last_recorded_time >= 1:
                        if current_second_speeds:
                            average_speed = sum(current_second_speeds) / len(current_second_speeds)
                            if average_speed > 0:
                                speeds[time] =+ average_speed
                                time += 1
                        current_second_speeds.clear()  # Clear for the next second
                        last_recorded_time += 1  # Update the last recorded time


                elif line == os.linesep:
                    started = True
                    start_time = time()

            # Final check for the last second's speeds
            if current_second_speeds:
                average_speed = sum(current_second_speeds) / len(current_second_speeds)
                #speeds.append(average_speed)
                #timestamps.append(elapsed_time)
                speeds[int(elapsed_time) + 1] =+ average_speed
                current_second_speeds.clear()
                if elapsed_time + 1 > max_time:
                    max_time = elapsed_time + 1
                print(max_time)
                print(last_recorded_time)

            sleep(1)

        sanitized_file_name = file.split('/')[-1]  # Get the file name without extension

        file_output = open(f'plots/{program}_{sanitized_file_name}.csv', "w");
        file_output.write("timestamp; speed\n")

        for i in range(0, int(max_time) + 1):
            for speeds[i] != 
            file_output.write(f"{i}; {speeds[i]/10}\n")

        print(time() - start_time)

        file_output.close()

