#!/usr/bin/env python3

import subprocess
import os
import re
import sys
from time import sleep, time
import matplotlib.pyplot as plt
import threading

def run_script(script_name, mode):
    subprocess.run(["python", script_name, "-m", mode])

def convert_size(size_str):
    """Convert size string (e.g., '10K', '100M') to bytes."""
    suffix = size_str[-1]
    number = size_str[:-1]
    numer = number.replace(',', '.')


    if suffix == 'K':
        return float(numer)
    elif suffix == 'M':
        return float(numer) * 10 ** 3
    elif suffix == 'G':
        return float(numer) * 10 ** 6
    return float(numer)

files = [
    #'143.54.50.1/downloads/example-fake-zip-file-1mb.zip'
#    '143.54.50.1/downloads/block_1B',
#    '143.54.50.1/downloads/block_2B',
#    '143.54.50.1/downloads/block_4B',
#    '143.54.50.1/downloads/block_8B',
#    '143.54.50.1/downloads/block_16B',
#    '143.54.50.1/downloads/block_32B',
#    '143.54.50.1/downloads/block_64B',
#    '143.54.50.1/downloads/block_128B'
    '143.54.50.1/downloads/file_zip'
]

lora = threading.Thread(target=run_script, args=("transceiver_download.py", "trim-and-compress"))
lora.daemon = True
lora.start()

sleep(1)

for file in files:
    sanitized_file_name = file.split('/')[-1].replace('.txt', '')  # Get the file name without extension
    file_output_path = f'saves5/{sanitized_file_name}.txt'

    with open(file_output_path, "a") as file_output:
        for i in range(10):
            command = ["wget", file, "-P", "TRASH/"]
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

            # Capture stdout and stderr
            #stdout_lines = result.stdout.splitlines()
            stderr_lines = result.stderr.splitlines()

            # Get the last line of stdout and stderr
            #last_stdout_line = stdout_lines[-2] if stdout_lines else ""
            last_stderr_line1 = stderr_lines[-4] if stderr_lines else ""
            last_stderr_line2 = stderr_lines[-2] if stderr_lines else ""

            # Write only the last lines to the output file
            file_output.write(last_stderr_line1 + "\n")
            file_output.write(last_stderr_line2 + "\n")
            print("Download {} finished!".format(i))

            sleep(1)
print("Download results saved to plots directory.")
