#!/usr/bin/env python3

import sys, threading, argparse
from time import sleep, monotonic
from collections import deque
from scapy.all import *
from SX127x.LoRa import *
from SX127x.board_config import BOARD
import socket
import struct

BOARD.setup()
verbose = False

TREDBOLD = '\033[31;1m'
TGREEN = '\033[32m'
TYELLOW = '\033[33m'

lock = threading.Lock()

def timestamp():
    """Returns the time elapsed since the program started."""
    return f"[{monotonic() - lora.start_time:.4f}s] "

def get_user_input(prompt, min_value=None, max_value=None):
    while True:
        try:
            user_input = int(input(prompt))
            if (min_value is not None and user_input < min_value) or (max_value is not None and user_input > max_value):
                raise ValueError
            return user_input
        except ValueError:
            print(f"Error: Please enter a valid integer within the specified range ({min_value} - {max_value}).")

def get_ttl(packet):
    return packet[IP].ttl if packet.haslayer(IP) else None

class Handler(threading.Thread):
    def __init__(self):
        super().__init__()
        self.tx_wait = False
        self.rx_wait = False
        self.end = False
        self.ack_received = False
        self.repetitions = get_user_input("Please enter the number for repetitions: ", 1)
        self.packet_size = get_user_input("Please choose the size of the packet in b (between 64 and 1500): ", 64, 1500)
        self.iteration_times = []
        print(TYELLOW + f"Starting iteration with {self.repetitions} repetitions remaining.")
        self.sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
        self.sock.bind((pktin, 0))
        self.daemon = True
        self.sock.setblocking(False)
        self.packets = deque()

    def end_test(self):
        self.repetitions -= 1
        if self.repetitions > 0:
            self.reset_for_next_iteration()
        else:
            self.calculate_average_time()
            self.end = True
            print(timestamp() + "All iterations completed, exiting...")
            sys.exit(0)

    def calculate_average_time(self):
        if self.iteration_times:
            average_time = sum(self.iteration_times) / len(self.iteration_times)
            print(TGREEN + timestamp() + f"Average transmission time: {average_time:.4f}s")
        else:
            print(TREDBOLD + timestamp() + "No iteration times recorded.")

    def reset_for_next_iteration(self):
        sleep(1)
        print(TYELLOW + timestamp() + f"{self.repetitions} repetitions remaining.")
        self.ack_received = False
        self.reinitialize_lora_module()
        self.iteration_start_time = monotonic()

    def reinitialize_lora_module(self):
        lora.set_mode(MODE.SLEEP)
        lora.set_max_payload_length(128)
        lora.set_pa_config(pa_select=1)
        lora.set_bw(9)
        lora.set_freq(915)
        lora.reset_ptr_rx()
        lora.clear_irq_flags()
        lora.set_dio_mapping([0] * 6)
        lora.set_mode(MODE.RXCONT)
        print(timestamp() + "Reinitialized LoRa module and set to RX mode")

    def run(self):
        self.iteration_start_time = monotonic()
        while not self.end:
            while self.rx_wait:
                with lock:
                    self.rx_wait = 0
                    sleep(0.6)
            if not self.tx_wait and not self.ack_received: # If not waiting for transmission and packets in queue
                lora.start_time = monotonic()
                data = Ether() / IP() / TCP() / ('z' * self.packet_size)
                ttl = get_ttl(data)
                if ttl is not None:
                    print(f"TTL of the packet: {ttl}")

                for packet in self.split(bytes(data)):
                    print(timestamp() + f"Sending packet fragment: {packet} length" + f'{len(packet)}')
                    lora.write_payload(list(packet))
                    lora.set_dio_mapping([1, 0, 0, 0, 0, 0])
                    lora.set_mode(MODE.TX)
                    self.tx_wait = True

                while not self.ack_received and not self.end:
                    sleep(0.1)

        print(timestamp() + "Ack received, test ended")
        sys.exit()

    def split(self, data):
        return [data[i:i + 127] for i in range(0, len(data), 127)]

class LoRaSocket(LoRa):
    def __init__(self, verbose=verbose):
        super(LoRaSocket, self).__init__(verbose)
        self.set_mode(MODE.SLEEP)
        self.set_pa_config(pa_select=1)
        self.set_max_payload_length(255)  # set max payload to max fifo buffer length
        self.set_dio_mapping([0] * 6)  # initialise DIO0 for rxdone
        self.sock = socket.socket(socket.PF_PACKET, socket.SOCK_RAW, socket.htons(0x0800))
        self.sock.bind((pktout, socket.htons(0x0800)))

    def on_rx_done(self):
        self.clear_irq_flags(RxDone=1)  # clear receive flags and prepare antenna for new tx/rx
        self.reset_ptr_rx()
        self.set_mode(MODE.RXCONT)

        payload = self.read_payload(nocheck=True)  # Reads the antenna
        print(TYELLOW + timestamp() + f"RX done, received payload: {payload}")

        if not self.testBit(payload[6], 5):
            with lock:
                handler.rx_wait = 1

        # Put the new payload into the queue for processing
        self.sock.send(bytes(payload))

        if len(payload) == 3 and ''.join(map(chr, payload)) == "ACK":
            print(TGREEN + timestamp() + "Received ACK!")
            iteration_time = monotonic() - handler.iteration_start_time
            print(timestamp() + f"Iteration Transmission time: {iteration_time:.4f}s")
            handler.iteration_times.append(iteration_time)
            handler.ack_received = True
            handler.end_test()


    def on_tx_done(self):  # Resets LoRa after transmission
        self.clear_irq_flags(TxDone=1)
        self.set_dio_mapping([0] * 6)
        self.set_mode(MODE.RXCONT)
        handler.tx_wait = False
        print(TYELLOW + timestamp() + "TX done, switched to RX mode")
        if host == 'middle':
            handler.end_test()

    def shutdown(self):
        # Signal the PayloadProcessor to exit and clean up
        self.queue.put(None)
        self.payload_processor.join()

    def testBit(self, int_val, offset):  # Tests if the bit in the offset is zero
        return (int_val & (1 << offset)) != 1

if __name__ == '__main__':
    #./transceiver.py -i INTERFACE_IN -o INTERFACE_OUT -v
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--in", dest="pktin", default="wlan0", help="Sniffed Interface (packet in)", required=False)
    parser.add_argument("-o", "--out", dest="pktout", default="lorarecv", help="Send Interface (packet out)", required=False)
    parser.add_argument("-m", "--mode", dest="mode", default="end", help="which host is running the code", required=False)
    parser.add_argument("-f", "--full-packet", dest="full_packet", help="Send full packet or only 255B", action='store_true')
    args = parser.parse_args()
    pktin = args.pktin
    pktout = args.pktout
    host = args.mode
    full_packet = args.full_packet

    handler = Handler()
    lora = LoRaSocket(verbose=False)
    lora.set_bw(9)
    lora.set_spreading_factor(7)
    lora.set_freq(915)
    print(lora)

    handler.start()

    try:
        lora.set_mode(MODE.RXCONT)
        while True:
            sleep(1)
            if handler.end:
                break
    finally:
        lora.set_mode(MODE.SLEEP)
        handler.sock.close()
        BOARD.teardown()
