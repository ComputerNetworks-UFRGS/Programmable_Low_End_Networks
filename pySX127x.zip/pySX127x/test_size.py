#!/usr/bin/env python3

import subprocess
import os
import re
import sys
from time import sleep, time
import matplotlib.pyplot as plt
import threading

def run_script(script_name, mode):
    subprocess.run(["python", script_name, "-m", mode])

def convert_size(size_str):
    """Convert size string (e.g., '10K', '100M') to bytes."""
    suffix = size_str[-1]
    number = size_str[:-1]
    numer = number.replace(',', '.')


    if suffix == 'K':
        return float(numer)
    elif suffix == 'M':
        return float(numer) * 10 ** 3
    elif suffix == 'G':
        return float(numer) * 10 ** 6
    return float(numer)

files = [
    '143.54.50.1/downloads/A1M.txt',
#    '143.54.50.1/downloads/A10M.txt',
    '143.54.50.1/downloads/AB1M.txt',
#    '143.54.50.1/downloads/AB10M.txt',
    '143.54.50.1/downloads/ABC1M.txt',
#    '143.54.50.1/downloads/ABC10M.txt',
    '143.54.50.1/downloads/example-fake-zip-file-1mb.zip'
]

lora = threading.Thread(target=run_script, args=("transceiver3.py", "trim-and-compress"))
lora.daemon = True
lora.start()

for file in files:
    for i in range(10):
        start_time = time()

        file_output = open(f'plots/{program}_{sanitized_file_name}.csv', "w");
        os.system('touch plots/{sanitized_file_name}.csv')
	os.system(f'wget {file} -P TRASH/ >> plots/{sanitized_file_name}.csv')

        //process = subprocess.Popen(['wget', file, '-P', 'TRASH/'], stderr=subprocess.PIPE)

        sleep(1)

    //sanitized_file_name = file.split('/')[-1].replace('.txt', '')  # Get the file name without extension

    //file_output = open(f'plots/{program}_{sanitized_file_name}.csv', "w");
    //file_output.write("timestamp; speed\n")

    //file_output.write(f"{i}; {speeds[i]/30}\n")

    //file_output.close()
