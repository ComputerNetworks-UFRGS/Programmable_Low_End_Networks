# Experiments

There are 3 rounds of experiments in this folder, however, we are taking in consideration only the measurements of the "take-3" folder.

That's because in the first round of experiments, we hadn't defined standards of measurements, for exemple, the right size of packets and the places where we would measure de latency (the specific interfaces). In the take 3 directory, there is a description of which interfaces we used to run the pings on. 

On the first round (take-1 folder) we hadn't recompiled the BMV2 without the debugging flags and we were logging every step of the BMV2 for debugging purposes.

On the second round (take-2 folder) we made measurements with different criteria, so they are not standarized.

### Why are we keepping all this records?

Every piece of data we generated is important for camparison reasons. All this information can be analysed and used on the future.
