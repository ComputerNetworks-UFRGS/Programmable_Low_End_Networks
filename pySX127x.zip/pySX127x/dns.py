#!/usr/bin/python3
from scapy.all import *

#a = Ether(src="00:00:00:00:00:00",dst="00:00:00:00:00:00")/IP(src="127.0.0.1",dst="127.0.0.1")/UDP(sport=RandShort(),dport=3000)/DNS(rd=1,qdcount=1,arcount=1,qd=DNSQR(qname="en.wikipedia.org",qtype="A",qclass="IN"),ar=DNSRROPT(rclass=4096))
#a = Ether("\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08\x00E\x00\x00UH\xcf\x00\x00@\x113\xc7\x7f\x00\x00\x01\x7f\x00\x00\x01\xd51\x0b\xb8\x00A\xfeT\x1a\x94\x01 \x00\x01\x00\x00\x00\x00\x00\x01\x02en\twikipedia\x03org\x00\x00\x01\x00\x01\x00\x00)\x10\x00\x00\x00\x00\x00\x00\x0c\x00\n\x00\x08\x8a,\xfe\x12\xd1]\xc9\xa0")
a = Ether(src="d8:3a:dd:88:ca:09",dst="7c:0e:ce:25:60:97")/IP(src="143.54.50.51",dst="143.54.11.9")/UDP(sport=RandShort(),dport=53)/DNS(rd=1,qdcount=1,arcount=1,qd=DNSQR(qname="en.wikipedia.org",qtype="ALL",qclass="IN"),ar=DNSRROPT(rclass=4096))
a.show()
ans = srp1(a, timeout=10, iface="eth0")
ans.show()
