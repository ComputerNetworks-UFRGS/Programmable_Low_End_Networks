#!/usr/bin/env python3

import sys, threading, argparse
from time import time,sleep
from scapy.all import *
from SX127x.LoRa import *
from SX127x.board_config import BOARD
import socket
import struct

BOARD.setup()
verbose = False

TREDBOLD =  '\033[31;1m'
TGREEN =  '\033[32m'
TYELLOW =  '\033[33m'

lock = threading.RLock()
pause_event = threading.Event()

class Handler(threading.Thread):
    def __init__(self):
        super().__init__()
        self.tx_wait = 0
        self.sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
        self.sock.bind((pktin, 0))
        self.daemon = True
        self.sock.setblocking(False)
        self.packets = deque()
        #self.packet = []

    def run(self):
        while True:
            #if pause_event.is_set():  # Check if the event is set
            #    sleep(0.4)
            #    pause_event.clear()  # Clear the event after sleeping
            #else:
            try:
                data = self.sock.recvfrom(1500)
                if not len(self.packets):
                    self.split(bytes(data[0]))
            except BlockingIOError:
                pass
            if not self.tx_wait and len(self.packets):
                packet = self.packets.popleft()
                lora.write_payload(list(packet))
                lora.set_dio_mapping([1,0,0,0,0,0]) # set DIO0 for txdone
                if verbose:
                    print(TYELLOW + "Sent packet with " + f'{len(packet)}' + "bytes")
                lora.set_mode(MODE.TX)
                self.tx_wait = True

    def split(self, data):
        Iter = 0
        packet = []
        if verbose:
            print(TREDBOLD + "Total len packet: " + f'{len(data)}')
        for i in range(0, len(data), 253):
            FLAG = 8 * [0]
            FLAG[0] = not Iter
            FLAG[5 - Iter] = 1
            Iter = Iter + 1
            flags = (FLAG[7]) | (FLAG[6] << 1) | (FLAG[5] << 2) | (FLAG[4] << 3) | (FLAG[3] << 4) | (FLAG[2] << 5) | (FLAG[1] << 6) | (FLAG[0] << 7)
            packet = data[i:i+253]
            self.packets.append(bytes([len(packet)]) + bytes([flags]) + packet)
            if verbose:
                print("Packet part " + f'{Iter}' + " split into " + f'{len(packet)}' + " bytes with int flags " + f'{flags}')
        FLAG[1] = 1
        flags = (FLAG[7]) | (FLAG[6] << 1) | (FLAG[5] << 2) | (FLAG[4] << 3) | (FLAG[3] << 4) | (FLAG[2] << 5) | (FLAG[1] << 6) | (FLAG[0] << 7)
        self.packets.pop()
        self.packets.append(bytes([len(packet)]) + bytes([flags]) + packet)
        if verbose:
            print("Packet part " + f'{Iter}' + " is last replaced with int flags " + f'{flags}')

class LoRaSocket(LoRa):
    def __init__(self, verbose=verbose):
        super(LoRaSocket, self).__init__(verbose)
        self.set_mode(MODE.SLEEP)
        self.set_pa_config(pa_select=1)
        self.set_max_payload_length(128) # set max payload to max fifo buffer length
        self.payload = []
        self.set_dio_mapping([0] * 6) #initialise DIO0 for rxdone
        self.sock  = socket.socket(socket.PF_PACKET, socket.SOCK_RAW, socket.htons(0x0800))
        self.sock.bind((pktout, socket.htons(0x0800)))

    # when LoRa receives data send to socket conn
    def on_rx_done(self):
        payload = self.read_payload(nocheck=True)
        if verbose:
            print(TGREEN + f'{len(payload)}' + " bytes in!")
        self.payload[:len(self.payload)] = payload
        isLast = (payload[1] & (1 << 6)) != 0
        if isLast:
            print("Last")
        isFirst = (payload[1] & (1 << 7)) != 0
        if isFirst:
            print("First")
        for offset in range(6):
            if payload[1] & (1 << offset):
                pktNum = offset - 1
        print(pktNum)
        # if piece received is the last one
        if len(payload) != 255:
            if len(self.payload) > 34:
                packet = Ether(bytes(self.payload))
                if verbose:
                    print("Full packet in!  " + packet.summary())

                threading.Thread(target=self.send_packet, args=(self.payload,)).start()
            self.payload = []

        self.clear_irq_flags(RxDone=1)  # clear rxdone IRQ flag
        self.reset_ptr_rx()
        self.set_mode(MODE.RXCONT)

    def on_tx_done(self):
        self.clear_irq_flags(TxDone=1) # clear txdone IRQ flag
        self.set_dio_mapping([0] * 6)
        self.set_mode(MODE.RXCONT)
        handler.tx_wait = 0

    def send_packet(self, packet):
        # This method sends the packet
        startPTime = datetime.now()
        self.sock.send(bytes(packet))
        stopPTime = datetime.now()
        calcTime = stopPTime - startPTime
        print (f'{startPTime} - {stopPTime} ({calcTime})')

    def testBit(self, int_type, offset):
        mask = 1 << offset
        return(int_type & mask)

if __name__ == '__main__':
    #./transceiver.py -i INTERFACE_IN -o INTERFACE_OUT -v
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--in", dest="pktin", default="lorasend", help="Sniffed Interface (packet in)", required=False)
    parser.add_argument("-o", "--out", dest="pktout", default="lorarecv", help="Send Interface (packet out)", required=False)
    parser.add_argument("-v", "--verbose", dest="verbose", help="Verbose mode", action='store_true')
    parser.add_argument("-m", "--mode", dest="mode", default="end", help="which host is running the code", required=False)
    args = parser.parse_args()
    pktin = args.pktin
    pktout = args.pktout
    host = args.mode
    verbose = args.verbose

    handler = Handler()
    lora = LoRaSocket(verbose=False)
    lora.set_bw(9)
    lora.set_freq(915)
    lora.set_max_payload_length(255)
    print(lora)

    handler.start()

    try:
        lora.set_mode(MODE.RXCONT)
        while True:
            pass
    finally:
        lora.set_mode(MODE.SLEEP)
        lora.sock.close()
        handler.sock.close()
        BOARD.teardown()
