#!/usr/bin/env python3

import sys, threading, argparse
from time import time,sleep
from scapy.all import *
from SX127x.LoRa import *
from SX127x.board_config import BOARD

BOARD.setup()
verbose = False

class LoRaSocket(LoRa):
    def __init__(self, verbose=verbose):
        super(LoRaSocket, self).__init__(verbose)
        self.set_mode(MODE.SLEEP)
        self.set_pa_config(pa_select=1)
        self.set_max_payload_length(128) # set max payload to max fifo buffer length
        self.payload = []
        self.set_dio_mapping([0] * 6) #initialise DIO0 for rxdone
        self.OWN_IP = get_if_addr(pktout)
        self.OWN_MAC = get_if_hwaddr(pktout)
        self.RMAC = "7c:0e:ce:25:60:97"
        self.tx_wait = 0

    # when LoRa receives data send to socket conn
    def on_rx_done(self):
        self.tx_wait = 1
        payload = self.read_payload(nocheck=True)
        self.payload += payload
        # if piece received is the last one
        if len(payload) != 127:
            print(len(self.payload))
            packet = Ether(bytes(self.payload))

            #if (verbose):
            print("Packet in!  " + packet.summary())

            if packet.haslayer(IP) and (not packet.haslayer(BOOTP)):
                packet[IP].src = self.OWN_IP
                packet[Ether].src = self.OWN_MAC
                packet[Ether].dst = self.RMAC
                del packet.chksum
                del packet[IP].chksum
                if packet.haslayer(TCP):
                    del packet[TCP].chksum
                if packet.haslayer(ICMP):
                    del packet[ICMP].chksum
                packet.show2()
                threading.Thread(target=self.send_packet, args=(packet,)).start()
            self.payload = []
            self_tx_wait = 0
            packet = ""
            #sleep(1)

        self.clear_irq_flags(RxDone=1) # clear rxdone IRQ flag
        self.reset_ptr_rx()
        self.set_mode(MODE.RXCONT)

    # after data sent by LoRa reset to receive mode
    def on_tx_done(self):
        self.clear_irq_flags(TxDone=1) # clear txdone IRQ flag
        self.set_dio_mapping([0] * 6)
        self.set_mode(MODE.RXCONT)
        self.tx_wait = 0

    def send_packet(self, packet):
        # This method sends the packet
        p = srp1(packet, iface="eth0")
        if not self.tx_wait:
            print("A")
            packets = self.split(bytes(p))
            for pkt in packets:
                print("B")
                self.write_payload(list(pkt))
                self.set_dio_mapping([1,0,0,0,0,0]) # set DIO0 for txdone
                self.set_mode(MODE.TX)
                self.tx_wait = 1
                sleep(1)
            sleep(1)

if __name__ == '__main__':
    #./transceiver.py -i INTERFACE_IN -o INTERFACE_OUT -v
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--in", dest="pktin", default="lorasend", help="Sniffed Interface (packet in)", required=False)
    parser.add_argument("-o", "--out", dest="pktout", default="lorarecv", help="Send Interface (packet out)", required=False)
    parser.add_argument("-v", "--verbose", dest="verbose", help="Verbose mode", action='store_true')
    parser.add_argument("-m", "--mode", dest="mode", default="end", help="which host is running the code", required=False)
    args = parser.parse_args()
    pktin = args.pktin
    pktout = args.pktout
    host = args.mode
    verbose = args.verbose

    if not verbose:
        print("You are running on silent mode!")

    lora = LoRaSocket(verbose=False)
    lora.set_bw(9)
    lora.set_freq(915)

    try:
        lora.set_mode(MODE.RXCONT)
        while True:
            pass
    finally:
        lora.set_mode(MODE.SLEEP)
        BOARD.teardown()
