from scapy.all import *

#get_if_addr(iface)
#get_if_hwaddr(iface)

ping_req = Ether(dst='fa:ec:-1e:64:83:f6',src='66:57:f5:35:f4:fe')/IP(src='10.0.0.1',dst='8.8.8.8')/ICMP()

#ping_req = Ether(src=get_if_hwaddr("ns1_inside"))/IP(src=get_if_addr("ns1_inside"),dst="8.8.8.8")/ICMP()
answer = srp1(ping_req, verbose=0, iface="ns-scapy-in")
answer.show()
