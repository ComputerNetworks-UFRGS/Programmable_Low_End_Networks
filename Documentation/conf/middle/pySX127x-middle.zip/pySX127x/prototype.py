#!/usr/bin/env python3

import sys, threading, argparse
from time import time,sleep
from scapy.all import *
from SX127x.LoRa import *
from SX127x.board_config import BOARD
import socket

BOARD.setup()
verbose = False

TREDBOLD =  '\033[31;1m'
TGREEN =  '\033[32m' 
TYELLOW =  '\033[33m'

class Queue:
    def __init__(self):
        self.items = []
        self.block = False

    def isEmpty(self):
        return self.items == []

    def enqueue(self, item):
        if not self.block:
            print(self.size())
            self.items.insert(0,item)
            self.block = self.size() > 10
        else:
            self.block = not self.isEmpty()


    def dequeue(self):
        return self.items.pop()

    def size(self):
        return len(self.items)

class Handler:
    def __init__(self):
        self.tx_wait = 0
        self.pktlist = Queue()
        self.list = []

    def run(self):
        while True:
            # while there are packets to send
            if (not self.tx_wait) and (not self.pktlist.isEmpty()):
                # gets a packet from the queue
                data = self.pktlist.dequeue()
                # breaks it into pieces
                packets = self.split(data)

                # sends the pieces one by one
                for packet in packets:
                    lora.write_payload(list(packet))
                    lora.set_dio_mapping([1,0,0,0,0,0]) # set DIO0 for txdone
                    lora.set_mode(MODE.TX)
                    self.tx_wait = 1
                    sleep(0.5) # less time for better transmision
            sleep(0.5)

    def pushpkt(self, packet):
        # if is valid packet
        if packet.haslayer(IP):
            if packet[IP].src in self.list and packet[IP].dst != "143.54.49.51":
                # the packet is converted into bytes and added to the queue
                if packet.haslayer(DNS):
                    if packet[DNSQR].qname.decode().endswith('.local.'):
                        return
                self.pktlist.enqueue(bytes(packet))
                print(TYELLOW + "SEND: ")
                print(packet.summary())

            else:
                if packet.haslayer(BOOTP):
                    if host == "end":
                        if (packet[BOOTP].yiaddr != '0.0.0.0' and (packet[BOOTP].yiaddr not in self.list)):
                            self.list.append(packet[BOOTP].yiaddr)
                            if verbose:
                                print(self.list)
                                print(f"IP {packet[BOOTP].yiaddr}" )
        packet = []

    def split(self, data):
        packets = []
        for i in range(0, len(data), 127):
            packet = data[i:i + 127]
            packets.append(packet)

        return packets

class LoRaSocket(LoRa):
    def __init__(self, verbose=verbose):
        super(LoRaSocket, self).__init__(verbose)
        self.set_mode(MODE.SLEEP)
        self.set_pa_config(pa_select=1)
        self.set_max_payload_length(128) # set max payload to max fifo buffer length
        self.payload = []
        self.set_dio_mapping([0] * 6) #initialise DIO0 for rxdone
#        self.sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW)
#        self.s = socket.socket()
#        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#        self.s.connect((get_if_addr("eth0"),80))
#        self.TCPsocket = StreamSocket(self.s)
#        self.UDPsocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    # when LoRa receives data send to socket conn
    def on_rx_done(self):
        handler.tx_wait = 1
        payload = self.read_payload(nocheck=True)
        self.payload += payload
        # if piece received is the last one
        if len(payload) != 127:
            if len(self.payload) > 34:
                packet = Ether(bytes(self.payload))

                print(handler.list)

                print(TGREEN + "Packet in!  " + packet.summary())

                # if it's not a DHCP packet
                if packet.haslayer(IP) and (not packet.haslayer(BOOTP)):
                    if host == "end":
                        threading.Thread(target=self.send_packet, args=(packet,)).start()

                    if host == "middle":
                        if (packet[IP].dst not in handler.list):
                            handler.list.append(packet[IP].dst)
                        if packet.haslayer(TCP):
                            try:
                            # Create a new TCP socket for each connection
                                with socket.socket() as temp_sock:
                                    temp_sock.bind(("143.54.49.51",0))
                                    temp_sock.connect((packet[IP].dst, packet[TCP].dport))
                                    temp_socket = StreamSocket(temp_sock, Raw)
                                    temp_socket.send(Raw(packet[IP]))
                            except Exception as e:
                                print(f"Connection error: {e}")
                        else:
                            try:
                                with socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_RAW) as temp_sock:
                                    temp_sock.bind(("143.54.49.51",0))
                                    if packet.haslayer(UDP):
                                        temp_sock.sendto(bytes(packet[IP]), (packet[1].dst, packet[2].dport))
                                    else:
                                        temp_sock.sendto(bytes(packet[IP]), (packet[1].dst, 0))
                            except Exception as e:
                                print(f"Connection error: {e}")
#                        else:
#                            packet.show()
#                            threading.Thread(target=self.send_packet, args=(packet,)).start()
            self.payload = []
            handler.tx_wait = 0
            packet = ""

        self.clear_irq_flags(RxDone=1) # clear rxdone IRQ flag
        self.reset_ptr_rx()
        self.set_mode(MODE.RXCONT)

    # after data sent by LoRa reset to receive mode
    def on_tx_done(self):
        self.clear_irq_flags(TxDone=1) # clear txdone IRQ flag
        self.set_dio_mapping([0] * 6)
        self.set_mode(MODE.RXCONT)
        handler.tx_wait = 0

    def send_packet(self, packet):
        # This method sends the packet
        sendp(packet, iface=pktout, realtime=True)

if __name__ == '__main__':
    #./transceiver.py -i INTERFACE_IN -o INTERFACE_OUT -v
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--in", dest="pktin", default="lorasend", help="Sniffed Interface (packet in)", required=False)
    parser.add_argument("-o", "--out", dest="pktout", default="lorarecv", help="Send Interface (packet out)", required=False)
    parser.add_argument("-v", "--verbose", dest="verbose", help="Verbose mode", action='store_true')
    parser.add_argument("-m", "--mode", dest="mode", default="end", help="which host is running the code", required=False)
    args = parser.parse_args()
    pktin = args.pktin
    pktout = args.pktout
    host = args.mode
    verbose = args.verbose

    # if not verbose:
    #     print(TREDBOLD + "You are running on silent mode!")

    handler = Handler()
    lora = LoRaSocket(verbose=False)
    lora.set_bw(9)
    lora.set_freq(915)

    Sniff = AsyncSniffer(prn=handler.pushpkt, filter="udp or icmp or (tcp and not (port 22 or port 53))", store=False, iface=pktin)
    Sniff.start()
    thread = threading.Thread(target=handler.run)
    thread.start()

    try:
        lora.set_mode(MODE.RXCONT)
        while True:
            pass
    finally:
        lora.set_mode(MODE.SLEEP)
        BOARD.teardown()
