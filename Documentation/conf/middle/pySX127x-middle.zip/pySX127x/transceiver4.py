#!/usr/bin/env python3

import sys
import threading
import argparse
from time import sleep
from scapy.all import *
from SX127x.LoRa import *
from SX127x.board_config import BOARD

BOARD.setup()
verbose = False

TREDBOLD =  '\033[31;1m'
TGREEN =  '\033[32m'
TYELLOW =  '\033[33m'

# Queue for list of packets captured
class Queue:
    def __init__(self):
        self.items = []
        self.block = False

    def isEmpty(self):
        return self.items == []

    def enqueue(self, item):
        if not self.block:
            print("Inserted")
            self.items.insert(0, item)
            # sets the queue size to at most 5 packets -> drops any packets when queue is full
            self.block = self.size() > 8
        else:
            self.block = not self.isEmpty()
    def dequeue(self):
        return self.items.pop()

    def size(self):
        return len(self.items)

# Handles LoRa send side of the program
class Handler:
    def __init__(self):
        self.pktlist = Queue()
        self.lock = threading.Lock()
        self.tx_wait = False

    def run(self):
        while True:
            acquired = self.lock.acquire(timeout=3)
            if acquired:
                try:
                    if not self.pktlist.isEmpty() and not self.tx_wait:
                        data = self.pktlist.dequeue()
                        print(TYELLOW + "SEND: ")
                        packet = Ether(data)
                        print(packet.summary())

                        lora.write_payload(list(data))
                        lora.set_dio_mapping([1, 0, 0, 0, 0, 0])  # set DIO0 flag for txdone
                        lora.set_mode(MODE.TX)  # sets LoRa mode to transmission
                        self.tx_wait = True
                finally:
                    self.lock.release()

    def pushpkt(self, packet):
        # If valid packet
        if packet.haslayer(IP):
            print(self.pktlist.size())
            # Enqueue packet in queue
            self.pktlist.enqueue(bytes(packet))

    def split(self, data):
        packets = []
        # Split packet into 127 bytes pieces
        for i in range(0, len(data), 127):
            packet = data[i:i + 127]
            packets.append(packet)

        return packets

# Handles LoRa RX and TX
class LoRaSocket(LoRa):
    def __init__(self, verbose=verbose):
        super(LoRaSocket, self).__init__(verbose)
        self.set_mode(MODE.SLEEP)  # sets LoRa to sleep to change configuration
        self.set_pa_config(pa_select=1)
        self.set_max_payload_length(128)  # set max payload to max fifo buffer length
        self.payload = []
        self.set_dio_mapping([0] * 6)  # initialise DIO0 flag for rxdone
        self.lock = threading.Lock()

    # When LoRa receives data send to socket conn
    def on_rx_done(self):
        with self.lock:
            # Reads from LoRa
            payload = self.read_payload(nocheck=True)
            self.payload += payload
            # If piece received is the last one
            if len(payload) != 127:
                if len(self.payload) > 34:
                    packet = Ether(bytes(self.payload))
                    packet.show()
                    print(TGREEN + "Packet in!  " + packet.summary())

                    # If it's not a DHCP packet
                    if packet.haslayer(IP):
                        threading.Thread(target=self.send_packet, args=(packet,)).start()
                self.payload = []
            self.clear_irq_flags(RxDone=1)  # clear rxdone IRQ flag
            self.reset_ptr_rx()
            self.set_mode(MODE.RXCONT)

    # After data sent by LoRa reset to receive mode
    def on_tx_done(self):
        with self.lock:
            self.clear_irq_flags(TxDone=1)  # clear txdone IRQ flag
            self.set_dio_mapping([0] * 6)
            self.set_mode(MODE.RXCONT)
            handler.tx_wait = False

    def send_packet(self, packet):
        # This method sends the packet
        sendp(packet, iface=pktout, realtime=True)

if __name__ == '__main__':
    # ./transceiver.py -i INTERFACE_IN -o INTERFACE_OUT -v
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--in", dest="pktin", default="lorasend", help="Sniffed Interface (packet in)", required=False)
    parser.add_argument("-o", "--out", dest="pktout", default="lorarecv", help="Send Interface (packet out)", required=False)
    parser.add_argument("-v", "--verbose", dest="verbose", help="Verbose mode", action='store_true')
    parser.add_argument("-m", "--mode", dest="mode", default="end", help="which host is running the code", required=False)
    args = parser.parse_args()
    pktin = args.pktin
    pktout = args.pktout
    host = args.mode
    verbose = args.verbose

    handler = Handler()
    lora = LoRaSocket(verbose=verbose)
    lora.set_bw(9)
    lora.set_freq(915)

    Sniff = AsyncSniffer(prn=handler.pushpkt, filter="icmp", store=False, iface=pktin)
    Sniff.start()
    thread = threading.Thread(target=handler.run)
    thread.start()

    try:
        lora.set_mode(MODE.RXCONT)
        while True:
            pass
    finally:
        lora.set_mode(MODE.SLEEP)
        BOARD.teardown()
