#!/usr/bin/env python3

from collections import deque
import sys, threading, argparse
from time import time,sleep
from scapy.all import *
from SX127x.LoRa import *
from SX127x.board_config import BOARD
import socket

BOARD.setup()
verbose = False

TREDBOLD =  '\033[31;1m'
TGREEN =  '\033[32m'
TYELLOW =  '\033[33m'

class Handler:
    def __init__(self):
        self.tx_wait = 0
        self.packets = deque()

    def run(self):
        while True:
            # while there are packets to send
            if len(self.packets) and not self.tx_wait:
                lora.write_payload(list(self.packets.popleft()))
                lora.set_dio_mapping([1,0,0,0,0,0]) # set DIO0 for txdone
                lora.set_mode(MODE.TX)
                self.tx_wait = True

    def pushpkt(self, packet):
        # if is valid packet
        if packet.haslayer(IP):
            if (len(self.packets) < 5):
                self.split(bytes(packet))
                print(TYELLOW + "SEND: ")
                packet.show()

    def split(self, data):
        for i in range(0, len(data), 127):
            self.packets.append(data[i:i + 127])

class LoRaSocket(LoRa):
    def __init__(self, verbose=verbose):
        super(LoRaSocket, self).__init__(verbose)
        self.set_mode(MODE.SLEEP)
        self.set_pa_config(pa_select=1)
        self.set_max_payload_length(128) # set max payload to max fifo buffer length
        self.payload = []
        self.set_dio_mapping([0] * 6) #initialise DIO0 for rxdone
        self.sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
        self.sock.bind((pktout, 0))

    # when LoRa receives data send to socket conn
    def on_rx_done(self):
        payload = self.read_payload(nocheck=True)
        self.payload += payload
        # if piece received is the last one
        if len(payload) != 127:
            if len(self.payload) > 34:
                packet = Ether(bytes(self.payload))
                packet.show()

                print(TGREEN + "Packet in!  " + packet.summary())

                # if it's not a DHCP packet
                if packet.haslayer(IP):
                    threading.Thread(target=self.send_packet, args=(packet,)).start()

            self.payload = []

        self.clear_irq_flags(RxDone=1) # clear rxdone IRQ flag
        self.reset_ptr_rx()
        self.set_mode(MODE.RXCONT)

    # after data sent by LoRa reset to receive mode
    def on_tx_done(self):
        self.clear_irq_flags(TxDone=1) # clear txdone IRQ flag
        self.set_dio_mapping([0] * 6)
        self.set_mode(MODE.RXCONT)
        sleep(0.5)
        handler.tx_wait = 0

    def send_packet(self, packet):
        # This method sends the packet
        startPTime = datetime.now()
        self.sock.send(bytes(packet))
        stopPTime = datetime.now()
        calcTime = stopPTime - startPTime
        print (f'{startPTime} - {stopPTime} ({calcTime})')


if __name__ == '__main__':
    #./transceiver.py -i INTERFACE_IN -o INTERFACE_OUT -v
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--in", dest="pktin", default="lorasend", help="Sniffed Interface (packet in)", required=False)
    parser.add_argument("-o", "--out", dest="pktout", default="lorarecv", help="Send Interface (packet out)", required=False)
    parser.add_argument("-v", "--verbose", dest="verbose", help="Verbose mode", action='store_true')
    parser.add_argument("-m", "--mode", dest="mode", default="end", help="which host is running the code", required=False)
    args = parser.parse_args()
    pktin = args.pktin
    pktout = args.pktout
    host = args.mode
    verbose = args.verbose

    handler = Handler()
    lora = LoRaSocket(verbose=False)
    lora.set_bw(9)
    lora.set_freq(915)

    Sniff = AsyncSniffer(prn=handler.pushpkt, filter="", store=False, iface=pktin)

    #Sniff = AsyncSniffer(prn=handler.pushpkt, filter="udp or icmp or (tcp and not (port 22 or port 53)) or port 67 or port 68", store=False, iface=pktin)
    Sniff.start()
#    if host == "middle":
#        NATSniff = AsyncSniffer(prn=NAT().pushpkt, store=False, iface="p4nat")
#        NATSniff.start()
    thread = threading.Thread(target=handler.run)
    thread.start()

    try:
        lora.set_mode(MODE.RXCONT)
        while True:
            pass
    finally:
        lora.set_mode(MODE.SLEEP)
        self.sock.close()
        BOARD.teardown()
