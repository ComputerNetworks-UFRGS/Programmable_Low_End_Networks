#!/usr/bin/env python3

import sys, threading, argparse
from time import sleep
from scapy.all import *
from SX127x.LoRa import *
from SX127x.board_config import BOARD

BOARD.setup()
verbose = False

TREDBOLD = '\033[31;1m'
TGREEN = '\033[32m'
TYELLOW = '\033[33m'

class Queue:
    def __init__(self):
        self.items = []

    def isEmpty(self):
        return self.items == []

    def enqueue(self, item):
        self.items.insert(0, item)

    def dequeue(self):
        return self.items.pop()

    def size(self):
        return len(self.items)

class Handler:
    def __init__(self, lora_socket):
        self.tx_wait = 0
        self.pktlist = Queue()
        self.list = []
        self.lora_socket = lora_socket

    def run(self):
        while True:
            if not self.tx_wait and not self.pktlist.isEmpty():
                data = self.pktlist.dequeue()
                packets = self.split(data)

                for packet in packets:
                    self.lora_socket.write_payload(list(packet))
                    self.lora_socket.set_dio_mapping([1, 0, 0, 0, 0, 0])
                    self.lora_socket.set_mode(MODE.TX)
                    self.tx_wait = 1
                    sleep(0.5)
            sleep(0.5)

    def pushpkt(self, packet):
        if packet.haslayer(IP) and packet.haslayer(Ether):
            print(TGREEN + "Received packet: " + packet.summary())
            packet.show()
            if packet.haslayer(BOOTP):
                if packet[IP].dst == "255.255.255.255":
                    # Forward DHCP requests to middle Raspberry Pi
                    packet[Ether].src = self.lora_socket.OWN_MAC
                    self.pktlist.enqueue(bytes(packet))
                    print(TYELLOW + "Forwarding DHCP request to middle Raspberry Pi")
                    print(packet.summary())
                    packet.show()
                elif packet[IP].src == "192.168.4.1":
                    # Forward DHCP responses back to the phone
                    for client_IP, client_MAC in self.list:
                        packet[IP].dst = client_IP
                        packet[Ether].dst = client_MAC
                        packet[Ether].src = self.lora_socket.OWN_MAC
                        del packet.chksum
                        del packet[IP].chksum
                        if packet.haslayer(TCP):
                            del packet[TCP].chksum
                        if packet.haslayer(UDP):
                            del packet[UDP].chksum
                        self.pktlist.enqueue(bytes(packet))
                        print(TYELLOW + "Forwarding DHCP response to phone")
                        print(packet.summary())
                else:
                    print(TREDBOLD + "Packet not processed: " + packet.summary())
    
    packet = []


    def split(self, data):
        packets = []
        for i in range(0, len(data), 127):
            packet = data[i:i + 127]
            packets.append(packet)
        return packets

class LoRaSocket(LoRa):
    def __init__(self, verbose=verbose):
        super(LoRaSocket, self).__init__(verbose)
        self.set_mode(MODE.SLEEP)
        self.set_pa_config(pa_select=1)
        self.set_max_payload_length(128)
        self.payload = []
        self.set_dio_mapping([0] * 6)
        self.OWN_IP = get_if_addr("wlan0")
        self.OWN_MAC = get_if_hwaddr("wlan0")
        self.RMAC = "7c:0e:ce:25:60:97"

    def on_rx_done(self):
        handler.tx_wait = 1
        payload = self.read_payload(nocheck=True)
        self.payload += payload
        if len(payload) != 127:
            print(len(self.payload))
            packet = Ether(bytes(self.payload))

#            print(TGREEN + "Packet in! " + packet.summary())
 #           packet.show()

            handler.pushpkt(packet)

            self.payload = []
            handler.tx_wait = 0

        self.clear_irq_flags(RxDone=1)
        self.reset_ptr_rx()
        self.set_mode(MODE.RXCONT)

    def on_tx_done(self):
        self.clear_irq_flags(TxDone=1)
        self.set_dio_mapping([0] * 6)
        self.set_mode(MODE.RXCONT)
        handler.tx_wait = 0

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--in", dest="pktin", default="lorasend", help="Sniffed Interface (packet in)", required=False)
    parser.add_argument("-o", "--out", dest="pktout", default="wlan0", help="Send Interface (packet out)", required=False)
    parser.add_argument("-v", "--verbose", help="Verbose mode", action='store_true')
    parser.add_argument("-m", "--mode", default="end", help="which host is running the code", required=False)
    args = parser.parse_args()
    pktin = args.pktin
    pktout = args.pktout
    host = args.mode
    verbose = args.verbose

    if not verbose:
        print(TREDBOLD + "You are running on silent mode!")

    lora = LoRaSocket(verbose=False)
    handler = Handler(lora)
    lora.set_bw(9)
    lora.set_freq(915)

    Sniff = AsyncSniffer(prn=handler.pushpkt, filter="udp port 67 or udp port 68", store=False, iface=pktin)
    Sniff.start()

    thread = threading.Thread(target=handler.run)
    thread.start()

    try:
        lora.set_mode(MODE.RXCONT)
        while True:
            pass
    finally:
        lora.set_mode(MODE.SLEEP)
        BOARD.teardown()
