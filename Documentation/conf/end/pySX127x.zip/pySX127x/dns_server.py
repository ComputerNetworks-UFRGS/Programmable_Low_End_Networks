#!/usr/bin/python3
# dns_server.py

from scapy.all import *
from socket import *

sock = socket(AF_INET, SOCK_DGRAM)
sock.bind( ("0.0.0.0", 3002) )

pkt, addr = sock.recvfrom(4096)

print(addr)
req = DNS(pkt)
req.show()
