#!/usr/bin/env python3

import sys, threading, argparse
from time import sleep, monotonic
from scapy.all import *
from SX127x.LoRa import *
from SX127x.board_config import BOARD

BOARD.setup()
verbose = False

TREDBOLD = '\033[31;1m'
TGREEN = '\033[32m'
TYELLOW = '\033[33m'

def timestamp():
    """Returns the time elapsed since the program started."""
    return f"[{monotonic() - lora.start_time:.4f}s] "

def get_user_input(prompt, min_value=None, max_value=None):
    while True:
        try:
            user_input = int(input(prompt))
            if (min_value is not None and user_input < min_value) or (max_value is not None and user_input > max_value):
                raise ValueError
            return user_input
        except ValueError:
            print(f"Error: Please enter a valid integer within the specified range ({min_value} - {max_value}).")

def get_ttl(packet):
    return packet[IP].ttl if packet.haslayer(IP) else None

class Handler:
    def __init__(self):
        self.tx_wait = False
        self.end = False
        self.ack_received = False
        self.repetitions = get_user_input("Please enter the number for repetitions: ", 1)
        self.packet_size = get_user_input("Please choose the size of the packet in b (between 64 and 1500): ", 64, 1500)
        self.iteration_times = []
        print(TYELLOW + f"Starting iteration with {self.repetitions} repetitions remaining.")

    def end_test(self):
        self.repetitions -= 1
        if self.repetitions > 0:
            self.reset_for_next_iteration()
        else:
            self.calculate_average_time()
            self.end = True
            print(timestamp() + "All iterations completed, exiting...")
            sys.exit(0)

    def calculate_average_time(self):
        if self.iteration_times:
            average_time = sum(self.iteration_times) / len(self.iteration_times)
            print(TGREEN + timestamp() + f"Average transmission time: {average_time:.4f}s")
        else:
            print(TREDBOLD + timestamp() + "No iteration times recorded.")

    def reset_for_next_iteration(self):
        sleep(1)
        print(TYELLOW + timestamp() + f"{self.repetitions} repetitions remaining.")
        self.ack_received = False
        self.reinitialize_lora_module()
        self.iteration_start_time = monotonic()

    def reinitialize_lora_module(self):
        lora.set_mode(MODE.SLEEP)
        lora.set_max_payload_length(128)
        lora.set_pa_config(pa_select=1)
        lora.set_bw(9)
        lora.set_freq(915)
        lora.reset_ptr_rx()
        lora.clear_irq_flags()
        lora.set_dio_mapping([0] * 6)
        lora.set_mode(MODE.RXCONT)
        print(timestamp() + "Reinitialized LoRa module and set to RX mode")

    def run(self):
        self.iteration_start_time = monotonic()
        while not self.end:
            if not self.tx_wait and not self.ack_received:
                lora.start_time = monotonic()
                data = Ether() / IP() / TCP() / ('z' * self.packet_size)
                ttl = get_ttl(data)
                if ttl is not None:
                    print(f"TTL of the packet: {ttl}")

                for packet in self.split(bytes(data)):
                    print(timestamp() + f"Sending packet fragment: {packet}")
                    lora.write_payload(list(packet))
                    lora.set_dio_mapping([1, 0, 0, 0, 0, 0])
                    lora.set_mode(MODE.TX)
                    self.tx_wait = True
                    sleep(0.5)

                while not self.ack_received and not self.end:
                    sleep(1)
                    print(timestamp() + "Waiting for ACK...")

            sleep(0.5)

        print(timestamp() + "Exiting...")
        sys.exit()

    def split(self, data):
        return [data[i:i + 127] for i in range(0, len(data), 127)]

class LoRaSocket(LoRa):
    def __init__(self, verbose=verbose):
        super().__init__(verbose)
        self.set_mode(MODE.SLEEP)
        self.set_pa_config(pa_select=1)
        self.set_max_payload_length(128)
        self.set_dio_mapping([0] * 6)
        self.payload = []

    def on_rx_done(self):
        try:
            handler.tx_wait = False
            payload = self.read_payload(nocheck=True)
            self.payload.extend(payload)
            print(TYELLOW + timestamp() + f"RX done, received payload: {payload}")

            if len(payload) == 3 and ''.join(map(chr, payload)) == "ACK":
                print(TGREEN + timestamp() + "Received ACK!")
                iteration_time = monotonic() - handler.iteration_start_time
                print(timestamp() + f"Iteration Transmission time: {iteration_time:.4f}s")
                handler.iteration_times.append(iteration_time)
                handler.ack_received = True
                handler.end_test()

            self.clear_irq_flags(RxDone=1)
            self.reset_ptr_rx()
            lora.set_mode(MODE.RXCONT)

        except OSError as e:
            print(f"Error in on_rx_done: {e}")
            handler.end_test()

    def on_tx_done(self):
        try:
            self.clear_irq_flags(TxDone=1)
            sleep(0.1)
            self.set_mode(MODE.RXCONT)
            handler.tx_wait = False
            print(TYELLOW + timestamp() + "TX done, switched to RX mode")
            if host == 'middle':
                handler.end_test()

        except OSError as e:
            print(f"Error in on_tx_done: {e}")
            handler.end_test()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--in", dest="pktin", default="wlan0", help="Sniffed Interface (packet in)", required=False)
    parser.add_argument("-o", "--out", dest="pktout", default="lorarecv", help="Send Interface (packet out)", required=False)
    parser.add_argument("-m", "--mode", dest="mode", default="end", help="which host is running the code", required=False)
    parser.add_argument("-f", "--full-packet", dest="full_packet", help="Send full packet or only 127B", action='store_true')
    args = parser.parse_args()
    pktin = args.pktin
    host = args.mode
    full_packet = args.full_packet

    handler = Handler()
    lora = LoRaSocket(verbose=True)
    lora.set_bw(9)
    lora.set_freq(915)

    thread = threading.Thread(target=handler.run)
    thread.start()

    try:
        while True:
            sleep(0.1)
            if handler.end:
                break
    finally:
        lora.set_mode(MODE.SLEEP)
        BOARD.teardown()
