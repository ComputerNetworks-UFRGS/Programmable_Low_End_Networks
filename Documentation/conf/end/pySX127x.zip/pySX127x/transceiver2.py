#!/usr/bin/env python3

import sys, threading, argparse
from time import time,sleep
from scapy.all import *
from SX127x.LoRa import *
from SX127x.board_config import BOARD
import socket
import struct

BOARD.setup()
verbose = False

TREDBOLD =  '\033[31;1m'
TGREEN =  '\033[32m'
TYELLOW =  '\033[33m'

lock = threading.RLock()

class Handler(threading.Thread):
    def __init__(self):
        super().__init__()
        self.tx_wait = 0
        self.sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
        self.sock.bind((pktin, 0))
        self.daemon = True
        self.packets = deque()

    def run(self):
        while True:
            data = self.sock.recvfrom(1500)
            packet = Ether(data[0])
            if packet[IP].dst == "143.54.48.186":
                self.split(bytes(data[0]))
                print(TYELLOW + "SEND: ")
                print(packet.summary())
            if not self.tx_wait and len(self.packets):
                with lock:
                    lora.write_payload(list(self.packets.popleft()))
                    lora.set_dio_mapping([1,0,0,0,0,0]) # set DIO0 for txdone
                    lora.set_mode(MODE.TX)
                    self.tx_wait = True

    def split(self, data):
        if len(self.packets) < 10:
            for i in range(0, len(data), 255):
                self.packets.append(data[i:i + 255])

class LoRaSocket(LoRa):
    def __init__(self, verbose=verbose):
        super(LoRaSocket, self).__init__(verbose)
        self.set_mode(MODE.SLEEP)
        self.set_pa_config(pa_select=1)
        self.set_max_payload_length(128) # set max payload to max fifo buffer length
        self.payload = []
        self.set_dio_mapping([0] * 6) #initialise DIO0 for rxdone
        self.sock  = socket.socket(socket.PF_PACKET, socket.SOCK_RAW, socket.htons(0x0800))
        self.sock.bind((pktout, socket.htons(0x0800)))

    # when LoRa receives data send to socket conn
    def on_rx_done(self):
        with lock:  # Acquire the lock before accessing the payload
            payload = self.read_payload(nocheck=True)
            self.payload += payload
            # if piece received is the last one
            if len(payload) != 255:
                if len(self.payload) > 34:
                    packet = Ether(bytes(self.payload))

                    print(TGREEN + "Packet in!  " + packet.summary())

                    threading.Thread(target=self.send_packet, args=(self.payload,)).start()
                self.payload = []

            self.clear_irq_flags(RxDone=1)  # clear rxdone IRQ flag
            self.reset_ptr_rx()
            self.set_mode(MODE.RXCONT)

    def on_tx_done(self):
        self.clear_irq_flags(TxDone=1) # clear txdone IRQ flag
        self.set_dio_mapping([0] * 6)
        self.set_mode(MODE.RXCONT)
        handler.tx_wait = 0

    def send_packet(self, packet):
        # This method sends the packet
        startPTime = datetime.now()
        self.sock.send(bytes(packet))
        stopPTime = datetime.now()
        calcTime = stopPTime - startPTime
        print (f'{startPTime} - {stopPTime} ({calcTime})')


if __name__ == '__main__':
    #./transceiver.py -i INTERFACE_IN -o INTERFACE_OUT -v
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--in", dest="pktin", default="lorasend", help="Sniffed Interface (packet in)", required=False)
    parser.add_argument("-o", "--out", dest="pktout", default="lorarecv", help="Send Interface (packet out)", required=False)
    parser.add_argument("-v", "--verbose", dest="verbose", help="Verbose mode", action='store_true')
    parser.add_argument("-m", "--mode", dest="mode", default="end", help="which host is running the code", required=False)
    args = parser.parse_args()
    pktin = args.pktin
    pktout = args.pktout
    host = args.mode
    verbose = args.verbose

    handler = Handler()
    lora = LoRaSocket(verbose=False)
    lora.set_bw(9)
    lora.set_freq(915)
    lora.set_max_payload_length(255)
    print(lora)

    handler.start()

    try:
        lora.set_mode(MODE.RXCONT)
        while True:
            pass
    finally:
        lora.set_mode(MODE.SLEEP)
        lora.sock.close()
        handler.sock.close()
        BOARD.teardown()
