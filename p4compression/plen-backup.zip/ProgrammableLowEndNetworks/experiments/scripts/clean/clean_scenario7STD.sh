#! /bin/bash
rm results/scenario7/STD-WGET-256k.txt
