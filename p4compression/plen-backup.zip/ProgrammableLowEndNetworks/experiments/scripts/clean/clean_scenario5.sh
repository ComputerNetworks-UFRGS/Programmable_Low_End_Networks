#! /bin/bash
rm results/scenario5/LTP-UDP-256k-1448b-h1-h4.txt
rm results/scenario5/LTP-UDP-256k-1448b-h7-h2.txt
rm results/scenario5/LTP-UDP-256k-1448b-h5-h8.txt
rm results/scenario5/LTP-TCP-256k-1448b-h1-h4.txt
rm results/scenario5/LTP-TCP-256k-1448b-h7-h2.txt
rm results/scenario5/LTP-TCP-256k-1448b-h5-h8.txt
