#! /bin/bash
rm results/scenario6/LTP-TCP-256k-1448b-h1-h6.txt
rm results/scenario6/LTP-TCP-256k-1448b-h2-h7.txt
rm results/scenario6/LTP-TCP-256k-1448b-h3-h8.txt
rm results/scenario6/LTP-TCP-256k-1448b-h4-h9.txt
rm results/scenario6/LTP-TCP-256k-1448b-h5-h10.txt
