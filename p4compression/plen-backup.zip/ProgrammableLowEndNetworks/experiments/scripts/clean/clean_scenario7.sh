#! /bin/bash
rm results/scenario7/LTP-WGET-256k.txt
