#! /bin/bash
echo > logs/s1.log
echo > logs/s1-p4runtime-requests.txt
echo > logs/s2.log
echo > logs/s2-p4runtime-requests.txt
echo > logs/s3.log
echo > logs/s3-p4runtime-requests.txt
echo > logs/s4.log
echo > logs/s4-p4runtime-requests.txt
